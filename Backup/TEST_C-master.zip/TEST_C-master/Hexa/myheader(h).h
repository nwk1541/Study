#include<stdio.h>
#include<stdlib.h>
#include<conio.h>
#include<time.h>
#include<windows.h>

#pragma warning (disable:4996)
#pragma warning (disable:4761)

#define LEFT 75
#define RIGHT 77
#define UP 72
#define DOWN 80
#define ESC 27
#define PGUP 73
#define PGDN 81

#define CLS system("cls")
#define delay(n) Sleep(n)
#define init_rand() srand((unsigned)time(NULL))
#define make_rand(n) (rand() % (n))

typedef enum { NOCURSOR, SOLIDCURSOR, NORMALCURSOR }CURSOR_TYPE;
void gotoxy(int x, int y);
void SetCursorType(CURSOR_TYPE c);

void gotoxy(int x, int y)
{
	COORD Cur;

	Cur.X = x;
	Cur.Y = y;

	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), Cur);
}
void SetCursorType(CURSOR_TYPE c)
{
	CONSOLE_CURSOR_INFO Curinfo;

	switch (c)
	{
	case NOCURSOR:
		Curinfo.dwSize = 1;
		Curinfo.bVisible = FALSE;
		break;
	case SOLIDCURSOR:
		Curinfo.dwSize = 100;
		Curinfo.bVisible = TRUE;
		break;
	case NORMALCURSOR:
		Curinfo.dwSize = 20;
		Curinfo.bVisible = TRUE;
		break;
	}
	SetConsoleCursorInfo(GetStdHandle(STD_OUTPUT_HANDLE), &Curinfo);
}