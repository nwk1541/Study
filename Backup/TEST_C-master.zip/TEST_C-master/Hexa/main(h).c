#include "myheader(h).h"

#define BX 5
#define BY 1
#define BW 10
#define BH 20

void DrawScreen(void);
void DrawBoard(void);
void PrintBrick(BOOL Show);
void TestFull(void);
void DrawNext(void);
void PrintInfo(void);
void MakeNewBrick(void); // nbrick�迭�� ���̰� �ٸ� ������ ����
BOOL ProcessKey(void);
BOOL MoveDown(void);
int GetAround(int x, int y);

enum { EMPTY, B1, B2, B3, B4, B5, B6, B7, B8, B9, B10, WALL};
char *arTile[] = { ". ", "��", "��", "��", "��", "��", "��", "��", "��", "��", "��", "��" };
int board[BW + 2][BH + 2];
int nx, ny; // ���� �� ������ ��ǥ
int brick[3]; // �κ� ������ ������ ����
int nbrick[3];
int score;
int bricknum;
int level;

void main(void)
{
	int nFrame, nStay;
	int x, y;

	SetCursorType(NOCURSOR), init_rand();
	level = 6;

	for (; 1;)
	{
		CLS;
		for (x = 0; x < BW + 2; x++)
		{
			for (y = 0; y < BH + 2; y++)
			{
				board[x][y] = (y == 0 || y == BH + 1 || x == 0 || x == BW + 1) ? WALL : EMPTY;
			}
		}
		DrawScreen();
		nFrame = 20;
		score = 0;
		bricknum = 0;

		MakeNewBrick();
		for (; 2;)
		{
			bricknum++;
			memcpy(brick, nbrick, sizeof(brick));
			MakeNewBrick();
			DrawNext();
			nx = BW / 2, ny = 2;
			PrintBrick(TRUE);

			if (GetAround(nx, ny) != EMPTY) break;
			nStay = nFrame;
			for (; 3;)
			{
				if (--nStay == 0)
				{
					nStay = nFrame;
					if (MoveDown())break;
				}
				if (ProcessKey())break;
				delay(1000 / 20);
			}
			if (bricknum % 10 == 0 && nFrame > 5)
				nFrame--;
		}
		CLS;
		gotoxy(30, 12), puts("G A M E   O V E R");
		gotoxy(25, 14), puts("If you want restart press [ Y ]");
		if (tolower(getch()) != 'y') break;
	}
	SetCursorType(NORMALCURSOR);
}

void DrawScreen()
{
	int x, y;

	for (x = 0; x < BW + 2; x++)
	{
		for (y = 0; y < BH + 2; y++)
		{
			gotoxy(BX + x * 2, BY + y);
			puts(arTile[board[x][y]]);
		}
	}

	gotoxy(50, 3), puts("Hexa Ver.test");
	gotoxy(50, 5), puts("��:Move ��:Shift ��:Down");
	gotoxy(50, 6), puts("Space:Down Shift");
	gotoxy(50, 8), puts("P:Pause ESC:Exit");
	gotoxy(50, 9), puts("PgUp,PgDn:Level Control");
	DrawNext();
	PrintInfo();
}
void DrawBoard()
{
	int x, y;

	for (x = 1; x < BW + 1; x++)
	{
		for (y = 1; y < BH + 1; y++)
		{
			gotoxy(BX + x * 2, BY + y);
			puts(arTile[board[x][y]]);
		}
	}
}
BOOL ProcessKey()
{
	int ch;
	int t;

	if (kbhit())
	{
		ch = getch();
		if (ch == 0xE0 || ch == 0)
		{
			ch = getch();
			switch (ch)
			{
			case LEFT:
				if (GetAround(nx - 1, ny) == EMPTY)
				{
					PrintBrick(FALSE);
					nx--;
					PrintBrick(TRUE);
				}
				break;
			case RIGHT:
				if (GetAround(nx + 1, ny) == EMPTY)
				{
					PrintBrick(FALSE);
					nx++;
					PrintBrick(TRUE);
				}
				break;
			case UP:
				PrintBrick(FALSE);
				t = brick[0];
				brick[0] = brick[1];
				brick[1] = brick[2];
				brick[2] = t;
				PrintBrick(TRUE);
				break;
			case DOWN:
				if (MoveDown())
				{
					return TRUE;
				}
				break;
			case PGDN:
				if (level > 2)
				{
					level--;
					PrintInfo();
				}
				break;
			case PGUP:
				if (level < 10)
				{
					level++;
					PrintInfo();
				}
				break;
			}
		}
		else
		{
			switch (tolower(ch))
			{
			case ' ':
				while (MoveDown() == FALSE) { ; }
				return TRUE;
			case ESC:
				exit(0);
			case 'p':
				while (1)
				{
					gotoxy(20, 13), puts(" < PAUSE > press any key restart");
					delay(600);
					gotoxy(20, 13), puts("                                ");
					delay(600);
					if (kbhit())
						break;
				}
				DrawScreen();
				DrawNext();
				PrintBrick(TRUE);
				break;
			}
		}
	}
	return FALSE;
}
void PrintBrick(BOOL Show)
{
	int i;

	for (i = 0; i < 3; i++)
	{
		gotoxy(BX + nx * 2, BY + ny + i);
		puts(arTile[Show ? brick[i] : EMPTY]);
	}
}
int GetAround(int x, int y)
{
	int i, k = EMPTY;
	
	for (i = 0; i < 3; i++)
	{
		k = max(k, board[x][y + i]);
	}
	return k;
}
BOOL MoveDown()
{
	if (GetAround(nx, ny + 1) != EMPTY)
	{
		TestFull();
		return TRUE;
	}
	PrintBrick(FALSE);
	ny++;
	PrintBrick(TRUE);
	return FALSE;
}
void TestFull()
{
	int i, x, y;
	int t, ty;
	BOOL Remove;
	static int arScoreInfo[] = { 0, 1, 3, 7, 15, 30, 100, 500 };
	int count = 0;
	BOOL Mark[BW + 2][BH + 2];

	for (i = 0; i < 3; i++)
	{
		board[nx][ny + i] = brick[i];
	}

	while (1) // ���� ���� ����
	{
		memset(Mark, 0, sizeof(Mark));
		Remove = FALSE;

		for (y = 1; y < BH + 1; y++)
		{
			for (x = 1; x < BW + 1; x++)
			{
				t = board[x][y];
				if (t == EMPTY) continue;

				//����
				if (board[x - 1][y] == t && board[x + 1][y] == t)
				{
					for (i = -1; i <= 1; i++)
					{
						Mark[x + i][y] = TRUE;
					}
					Remove = TRUE;
				}
				//����
				if (board[x][y - 1] == t && board[x][y + 1] == t)
				{
					for (i = -1; i <= 1; i++)
					{
						Mark[x][y + i] = TRUE;
					}
					Remove = TRUE;
				}
				//������
				if (board[x - 1][y - 1] == t && board[x + 1][y + 1] == t)
				{
					for (i = -1; i <= 1; i++)
					{
						Mark[x + i][y + i] = TRUE;
					}
					Remove = TRUE;
				}
				//������
				if (board[x + 1][y - 1] == t && board[x - 1][y + 1] == t)
				{
					for (i = -1; i <= 1; i++)
					{
						Mark[x - i][y + i] = TRUE;
					}
					Remove = TRUE;
				}
			}
		}

		if (Remove == FALSE) return;

		for (i = 0; i < 6; i++) // ���� �ִϸ��̼�
		{
			for (y = 1; y < BH + 1; y++)
			{
				for (x = 1; x < BW + 1; x++)
				{
					if (board[x][y] != EMPTY && Mark[x][y] == TRUE)
					{
						gotoxy(BX + x * 2, BY + y);
						puts(arTile[i % 2 ? EMPTY : board[x][y]]);
					}
				}
			}
			delay(150);
		}

		for (y = 1; y < BH + 1; y++) // ���ӵ� ���� ����
		{
			for (x = 1; x < BW + 1; x++)
			{
				if (board[x][y] != EMPTY && Mark[x][y] == TRUE)
				{
					for (ty = y; ty>1; ty--)
					{
						board[x][ty] = board[x][ty - 1];
					}
					board[x][1] = EMPTY;
					count++;
				}
			}
		}
		DrawBoard();
		score = score + arScoreInfo[min(count / 3, 7)];
		PrintInfo();
	}
}
void DrawNext()
{
	int x, y, i;

	gotoxy(32, 1), puts("<Next Brick>");
	for (x = 32; x <= 42; x = x + 2)
	{
		for (y = 2; y <= 8; y++)
		{
			gotoxy(x, y);
			puts(arTile[(x == 32 || x == 42 || y == 2 || y == 8) ? WALL : EMPTY]);
		}
	}
	
	for (i = 0; i < 3; i++)
	{
		gotoxy(37, 4 + i);
		puts(arTile[nbrick[i]]);
	}
}
void PrintInfo()
{
	gotoxy(50, 11), printf("Level : %d ", level);
	gotoxy(50, 12), printf("Score : %d ", score);
	gotoxy(50, 13), printf("Brick : %d ", bricknum);
}
void MakeNewBrick()
{
	int i;

	do
	{
		for (i = 0; i < 3; i++)
		{
			nbrick[i] = make_rand(level) + 1;
		}
	} while (nbrick[0] == nbrick[1] && nbrick[1] == nbrick[2] && nbrick[0] == nbrick[2]);
}